package com.example.ejercicio_2_clase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio2ClaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio2ClaseApplication.class, args);
	}

}
