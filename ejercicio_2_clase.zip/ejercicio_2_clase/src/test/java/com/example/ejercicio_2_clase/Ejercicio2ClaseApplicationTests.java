package com.example.ejercicio_2_clase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio2ClaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
